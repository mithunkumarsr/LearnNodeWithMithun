const express = require('express');
const Joi = require('joi');
const app = express();

app.use(express.json());

// Joi validation schema
const userSchema = Joi.object({
    name: Joi.string().min(3).required(),
    email: Joi.string().email().required(),
    age: Joi.number().integer().min(18).max(65).required()
});

// Custom Error Class
class AppError extends Error {
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.isOperational = true;
    }
}

// POST route to create a user
app.post('/user', (req, res, next) => {
    const { error } = userSchema.validate(req.body);
    if (error) {
        return next(new AppError(error.details[0].message, 400));
    }
    res.send('User created successfully');
});

// Get user by ID
app.get('/user/:id', (req, res, next) => {
    const user = getUserById(req.params.id);
    if (!user) {
        return next(new AppError('User not found', 404));
    }
    res.status(200).json(user);
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
    if (err.isOperational) {
        return res.status(err.statusCode).json({
            status: 'fail',
            message: err.message
        });
    }
    res.status(500).json({
        status: 'error',
        message: 'Internal Server Error'
    });
});

// Starting the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
