// index.js

const express = require('express');
const app = express();
const loggingMiddleware = require('./loggingMiddleware');
const errorHandlingMiddleware = require('./errorHandlingMiddleware');
const port = 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Use the custom logging middleware
app.use(loggingMiddleware);

// Sample route
app.get('/', (req, res) => {
  res.send('Welcome to the Middleware and Routing Example!');
});

// Route that triggers an error
app.get('/error', (req, res) => {
  throw new Error('This is a forced error!');
});

// Use the custom error-handling middleware (should be after all routes)
app.use(errorHandlingMiddleware);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
