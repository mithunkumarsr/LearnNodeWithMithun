// Import the WebSocket library
const WebSocket = require('ws');

// Create a WebSocket server on port 8080
const wss = new WebSocket.Server({ port: 8080 });

// Handle client connections
wss.on('connection', (ws) => {
    console.log('New client connected');

    // Send a welcome message to the connected client
    ws.send('Welcome to the WebSocket server!');

    // Broadcast messages to all connected clients
    ws.on('message', (message) => {
        console.log(`Received: ${message}`);
        // Convert the message to a string before sending it
        const stringMessage = message.toString(); // Ensure it's a string
        console.log('Sending message:', stringMessage);
        // Broadcast the string message to all clients
        wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(stringMessage); // Send the received message to all connected clients
            }
        });
    });

    // Handle client disconnecting
    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

console.log('WebSocket server is running on ws://localhost:8080');
